package com.habitBuilder.habit_builder;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HabitBuilderApplicationTests {

	@Test
	void contextLoads() {
	}

}
