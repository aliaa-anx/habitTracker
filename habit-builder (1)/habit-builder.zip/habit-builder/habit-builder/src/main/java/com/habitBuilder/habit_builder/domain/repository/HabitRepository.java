package com.habitBuilder.habit_builder.domain.repository;

import com.habitBuilder.habit_builder.domain.model.HabitModel;

import java.util.List;

public interface HabitRepository {
    HabitModel findById(Integer id);
    HabitModel save(HabitModel habit);
    List<HabitModel> viewRecommendations(Integer userId);
}
