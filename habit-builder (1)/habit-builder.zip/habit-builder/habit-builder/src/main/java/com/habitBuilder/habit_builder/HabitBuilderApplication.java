package com.habitBuilder.habit_builder;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HabitBuilderApplication {

	public static void main(String[] args) {
		SpringApplication.run(HabitBuilderApplication.class, args);
	}

}
