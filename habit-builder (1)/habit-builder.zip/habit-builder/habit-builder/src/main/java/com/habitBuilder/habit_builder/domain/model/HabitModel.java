package com.habitBuilder.habit_builder.domain.model;

public class HabitModel {
    private Integer id;
    private Integer userId;
    private Integer categoryId;
    private String title;
    private Integer streak;

    public HabitModel(Integer id, Integer userId, Integer categoryId, String title, Integer streak) {
        this.id = id;
        this.userId = userId;
        this.categoryId = categoryId;
        this.title = title;
        this.streak = (streak != null) ? streak : 0;
    }
    public void setId(Integer id) {
        this.id = id;
    }
    public void setUserId(Integer userId) {
        this.userId = userId;
    }
    public void setCategoty(Integer categoty) {
        this.categoryId = categoty;
    }
    public void setTitle(String title) {
        this.title = title;
    }
    public void setStreak(Integer streak) {
        this.streak = streak;
    }
    public Integer getId() {
        return id;
    }
    public Integer getUserId() {
        return userId;
    }
    public Integer getCategoty() {
        return categoryId;
    }
    public String getTitle() {
        return title;
    }
    public Integer getStreak() {
        return streak;
    }
    public void markAsCompleted(){
        this.streak++;
    }
}
