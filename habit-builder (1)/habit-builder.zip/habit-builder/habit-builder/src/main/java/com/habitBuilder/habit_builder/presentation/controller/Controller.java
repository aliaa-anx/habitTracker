package com.habitBuilder.habit_builder.presentation.controller;

import com.habitBuilder.habit_builder.application.service.*;
import com.habitBuilder.habit_builder.domain.model.*;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/habit_builder")
public class Controller {

    private final UserService userService;
    private final HabitService habitService;
    private final GoalService goalService;
    private final ChallengeService challengeService;
    private final ChallengeParticipantsService challengeParticipantsService;
    // Injecting the services beans'
    public Controller(UserService userService, HabitService habitservice, GoalService goalService, ChallengeService challengeService,ChallengeParticipantsService challengeParticipantsService) {
        this.userService = userService;
        this.habitService = habitservice;
        this.goalService = goalService;
        this.challengeService=challengeService;
        this.challengeParticipantsService=challengeParticipantsService;
    }

    @PostMapping("/save-habit")
    public void saveHabit(@RequestBody HabitModel habit) {
        habitService.saveHabit(habit);
    }

    @PostMapping("/register")
    public void saveUser(@RequestBody UserModel user) {
        userService.saveUser(user);
    }

    @PostMapping("/login")
    public ResponseModel login(@RequestBody UserModel user) {
        return userService.login(user);
    }

    @PostMapping("/insert-goal")
    public void saveGoal(@RequestBody GoalModel goal) {
        goalService.saveGoal(goal);
    }

    @GetMapping("/get-goal")
    public GoalModel getGoal(@RequestParam Integer goalId){
        return goalService.getGoal(goalId);
    }

    @GetMapping("/get-user-goals")
    public List<GoalModel> getUserGoals(@RequestParam Integer userId){
        return goalService.getUserGoals(userId);
    }

    // when I want to increment the streak of this habit
    @PostMapping("/mark-as-completed")
    public void markAsCompleted(@RequestBody HabitModel habitModel){
        habitService.markAsCompleted(habitModel);
    }

    @GetMapping("/view-recommendations")
    public List<HabitModel> viewRecommendations(Integer userId){
        return habitService.viewRecommendations(userId);
    }

    @DeleteMapping("/delete-goal/{goalId}")
    public void deleteGoal(@PathVariable Integer goalId){
        goalService.deleteGoal(goalId);
    }

    // --- CHALLENGE ENDPOINTS ---

    @PostMapping("/create-challenge")
    public ChallengeModel createChallenge(@RequestBody ChallengeModel challenge) {
        return challengeService.createChallenge(challenge);
    }

    @GetMapping("/get-challenge")
    public ChallengeModel getChallenge(@RequestParam Integer id) {
        return challengeService.getChallenge(id);
    }

    @GetMapping("/get-all-challenges")
    public List<ChallengeModel> getAllChallenges() {
        return challengeService.getAllChallenges();
    }

    @DeleteMapping("/delete-challenge")
    public void deleteChallenge(@RequestParam Integer id) {
        challengeService.deleteChallenge(id);
    }

    @PostMapping("/join-challenge")
    public ChallengeParticipants joinChallenge(@RequestBody ChallengeParticipants challengeParticipants) {
        return challengeParticipantsService.joinChallenge(challengeParticipants);
    }

    @DeleteMapping("/leave-challenge")
    public void leaveChallenge(@RequestBody ChallengeParticipants challengeParticipants) {
        // Call the service to leave the challenge
        challengeParticipantsService.leaveChallenge(challengeParticipants.getUserId(), challengeParticipants.getChallengeId());
    }

    @PutMapping("/increment-progress")

    public ChallengeParticipants incrementProgress(@RequestBody ChallengeParticipants request){
       return challengeParticipantsService.incrementProgress( request.getUserId(), request.getChallengeId());
    }

    @PostMapping("/share-progress")

    public ChallengeProgress shareProgress(@RequestBody ChallengeParticipants request){
        return challengeParticipantsService.shareProgress(request.getUserId(), request.getChallengeId());

    }


}


