package com.habitBuilder.habit_builder.infrastructure.model;

import com.habitBuilder.habit_builder.domain.model.HabitModel;
import jakarta.persistence.*;
import jakarta.persistence.Id;

import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "habits")
public class HabitEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private Integer userId;
    private Integer categoryId;
    private String title;
    private Integer streak;

    // this won't show up in the database don't worry it's just a foreign key :)
    @ManyToOne
    @JoinColumn(name = "userId", referencedColumnName = "id", insertable = false, updatable = false)
    private UserEntity user;

    @ManyToOne
    @JoinColumn(name = "categoryId", referencedColumnName = "id", insertable = false, updatable = false)
    private CategoryEntity category;

    public HabitEntity(HabitModel habit) {
        this.id = habit.getId();
        this.userId = habit.getUserId();
        this.categoryId = habit.getCategoty();
        this.title = habit.getTitle();
        this.streak = habit.getStreak();
    }
    public HabitEntity(){}

    public HabitModel toDomain() {
        return new HabitModel(id, userId,categoryId, title, streak);
    }
    public static List<HabitModel> toDomain(List<HabitEntity> entityList) {
        List<HabitModel> domainList = new ArrayList<>();
        for (HabitEntity entity : entityList) {
            domainList.add(entity.toDomain()); // use the single converter
        }
        return domainList;
    }

    public static HabitEntity fromDomain(HabitModel habit) {
        return new HabitEntity(habit);
    }

}
