package com.habitBuilder.habit_builder.infrastructure.repository;

import com.habitBuilder.habit_builder.domain.model.HabitModel;
import com.habitBuilder.habit_builder.domain.repository.HabitRepository;
import com.habitBuilder.habit_builder.infrastructure.model.GoalEntity;
import com.habitBuilder.habit_builder.infrastructure.model.HabitEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

@Repository
public class HabitJpaRepository implements HabitRepository {

    private final SpringHabitRepository springRepo;
    private final SpringGoalRepository springGoalRepo;

    public HabitJpaRepository(SpringHabitRepository springRepo, SpringGoalRepository springGoalRepo) {
        this.springRepo = springRepo;
        this.springGoalRepo = springGoalRepo;
    }

    @Override
    public HabitModel findById(Integer id) {
        return springRepo.findById(id).get().toDomain();
    }

    @Override
    public HabitModel save(HabitModel habit) {
        HabitEntity entity = HabitEntity.fromDomain(habit);
        return springRepo.save(entity).toDomain();
    }

    @Override
    public List<HabitModel> viewRecommendations(Integer userId){
        List<GoalEntity> userGoals =  springGoalRepo.getUserGoals(userId);
        List<HabitEntity> recommendedHabits = new ArrayList<>();
        for(GoalEntity userGoal : userGoals){
            Integer categoryId = userGoal.toDomain().getHabitCategory();
            // to prevent duplication
            if(!recommendedHabits.containsAll(springRepo.getHabitsByCategory(categoryId)))
                recommendedHabits.addAll(springRepo.getHabitsByCategory(categoryId));
        }
        return HabitEntity.toDomain(recommendedHabits);
    }

//    interface SpringHabitRepository extends JpaRepository<HabitEntity, Integer> {}
}